package com.eyl.backend.enums;

public enum RoleEnum {
    MANAGER,WORKER
}
